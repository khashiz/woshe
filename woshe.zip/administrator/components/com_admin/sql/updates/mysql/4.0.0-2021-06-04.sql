-- after 4.0.0 RC1
UPDATE `#__template_styles`
   SET `title` = 'Atum - Default'
 WHERE `title` = 'atum - Default';

UPDATE `#__template_styles`
   SET `title` = 'Cassiopeia - Default'
 WHERE `title` = 'cassiopeia - Default';
